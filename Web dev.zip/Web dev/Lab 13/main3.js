let sum1 = 8;
let sum2 = 4;
let sum3 = 5;
let any = sum1 + sum2+sum3
console.log(any)