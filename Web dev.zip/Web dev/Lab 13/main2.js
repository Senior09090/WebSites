let a=4
let result = a*a*a*a*a
console.log(result)