function WordCount(str) { 
  return str.split(" ").length;
}