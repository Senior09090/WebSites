let insert_dash = window.prompt("Enter your string");

function insert_dash(str) {
   var chet = 0;
if (insert_dash[0] == '...'){
    return str.trim().toUpperCase().replace(/[^a-zA-Z0-9 -]/, "").replace(/\s/g, ".");
}
else {
    return "точки нету   "
}