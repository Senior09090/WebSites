let cart = [];

class Item {
  constructor(name, price, count, image) {
    this.name = name;
    this.price = price;
    this.count = count;
    this.image = image;
  }
}

const addItemToCart = (name, price, count, image) => {
  const existingItem = cart.find(item => item.name === name);
  if (existingItem) {
    existingItem.count = count; // Update the quantity to the desired value
    console.log("Item quantity updated in the cart");
  } else {
    const item = new Item(name, price, count, image);
    cart.push(item);
    console.log("Item added to the cart");
  }
  
  saveCart();
  displayCart();
};


const removeItemFromCart = name => {
  const itemIndex = cart.findIndex(item => item.name === name);
  if (itemIndex > -1) {
    cart.splice(itemIndex, 1);
    saveCart();
    displayCart();
  }
};

const displayCart = () => {
  let cartList = $("#cart-list");
  cartList.empty();

  let totalItems = 0;
  let totalCost = 0;

  for (let i in cart) {
    let item = cart[i];
    totalItems += item.count;
    totalCost += item.price * item.count;

    let cartItem = $("<li></li>");
    let cartImage = $("<img>").attr("src", item.image).attr("alt", item.name).addClass("cart-image");

    let cartInfo = $("<span></span>").text(`${item.name} $${item.price} x ${item.count} = $${item.price * item.count}`);

    let removeButton = $("<button></button>").addClass("remove-item").text("Remove");
    removeButton.on("click", () => {
      removeItemFromCart(item.name);
    });

    cartItem.append(cartImage);
    cartItem.append(cartInfo);
    cartItem.append(removeButton);

    cartList.append(cartItem);
  }

  $("#item-count").text(totalItems);
  $("#total-price").text(`$${totalCost.toFixed(2)}`);
};

const loadCart = () => {
  let storedCart = localStorage.getItem("cart");
  if (storedCart) {
    cart = JSON.parse(storedCart);
    console.log(cart);
  }
};

const saveCart = () => {
  localStorage.setItem("cart", JSON.stringify(cart));
};

$(".add-to-cart").click(function () {
  let parent = $(this).closest(".product-box");
  let name = parent.find(".product-name h4").text();
  let price = parseFloat(parent.find(".product-price ins").text().slice(1));
  let image = parent.find("img").attr("src");
  addItemToCart(name, price, 1, image);
});

$(".products").click(e => {
  if (!$(e.target).hasClass("add-to-cart")) {
    return;
  }
  let parent = $(e.target).closest(".product-box");
  let name = parent.find(".product-name h4").text();
  let price = parseFloat(parent.find(".product-price ins").text().slice(1));
  let image = parent.find("img").attr("src");
  addItemToCart(name, price, 1, image);
});

$("#cart").on("click", ".remove-item", function () {
  let name = $(this).prev().text().split(" ")[0];
  removeItemFromCart(name);
});

loadCart();
displayCart();
