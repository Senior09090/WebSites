let sum1  = Math.sin(9)
let sum2 = Math.cos(9)/2
let any = Math.max(sum1, sum2)
console.log()