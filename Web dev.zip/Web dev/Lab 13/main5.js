let sum1 = window.prompt("Enter side a");
let g ;
let f ; 
let j ; 
f = Math.sqrt(sum1);
g = Math.pow(sum1,2)
j = Math.abs(sum1)
console.log(f , g, j)