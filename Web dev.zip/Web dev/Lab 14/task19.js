function firstLetterWord(str)
    {
        let result = "";
        let v = true;
        for (let i = 0; i < str.length; i++)
        {
            // If it is space, set v as true.
            if (str[i] == ' ')
            {
                v = true;
        }
            else if (str[i] != ' ' && v == true)
            {
                result += (str[i]);
                v = false;
            }
        }
        return result;
    }
       
    let str = "geeks for geeks";
      document.write(firstLetterWord(str));
*/
