let e = 3;
let y = 4;
let w = 6;
let q = 9; 
let result = Math.max(4,5);
let result2 = Math.max(8,10);
let finalResult = Math.max(3,10);
console.log(result);
console.log(result2);
alert("Max integer " + finalResult)