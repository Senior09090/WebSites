var mystring = "Aldibek Enlik"; 
console.log(mystring[0]);
console.log(mystring[7]);
var my_student = "Tursyn Aizhuldyz"
console.log(my_student[0]);
console.log(my_student[8]);