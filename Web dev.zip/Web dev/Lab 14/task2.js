var str = "I love programming";   
while (str.indexOf(' ') > 0) { 
    str = str.replace(' ' , '');
    }
var strLength = str.length;
