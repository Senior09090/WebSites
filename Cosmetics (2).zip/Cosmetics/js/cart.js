let cart = [];

class Item {
  constructor(name, price, count, image) {
    this.name = name;
    this.price = price;
    this.count = count;
    this.image = image;
  }
}

const addItemToCart = (name, price, count, image) => {
  for (let i in cart) {
    if (cart[i].name === name) {
      cart[i].count += count;
      return;
    }
  }
  const item = new Item(name, price, count, image);
  cart.push(item);
  saveCart();
};

const removeItemFromCart = name => {
  for (let i in cart) {
    if (cart[i].name === name) {
      cart[i].count--;
      if (cart[i].count === 0) {
        cart.splice(i, 1);
      }
      break;
    }
  }
};

const displayCart = () => {
  let cartArray = [];
  let totalItems = 0;
  let totalCost = 0;
  for (let i in cart) {
    let item = cart[i];
    totalItems += item.count;
    totalCost += item.price * item.count;
    let itemHtml = `<li>
                      <img src="${item.image}" alt="${item.name}" class="cart-image">
                      <span>${item.name} $${item.price} x ${item.count} = $${item.price * item.count}</span>
                      <button class="remove-item">Remove</button>
                    </li>`;
    cartArray.push(itemHtml);
  }
  $("#cart-list").html(cartArray.join(""));
  $("#item-count").text(totalItems);
  $("#total-price").text(`$${totalCost.toFixed(2)}`);
};

const loadCart = () => {
  let storedCart = localStorage.getItem("cart");
  if (storedCart) {
    cart = JSON.parse(storedCart);
  }
};

const saveCart = () => {
  localStorage.setItem("cart", JSON.stringify(cart));
};



$(".add-to-cart").click(function() {
  let parent = $(this).closest(".product-box");
  let name = parent.find(".product-name h4").text();
  let price = parseFloat(parent.find(".product-price ins").text().slice(1));
  let image = parent.find("img").attr("src");
  addItemToCart(name, price, 1, image);
  displayCart();
});

$(".products").click(e => {
  if (!$(e.target).hasClass("add-to-cart")) {
    return;
  }
  let parent = $(e.target).closest(".product-box");
  let name = parent.find(".product-name h4").text();
  let price = parseFloat(parent.find(".product-price ins").text().slice(1));
  let image = parent.find("img").attr("src");
  addItemToCart(name, price, 1, image);
  displayCart();
});

$(".cart-product-remove .remove").click(function() {
  $(this).closest("tr").remove();
});

$("#cart").click(e => {
  if (!$(e.target).hasClass("remove-item")) {
    return;
  }
  let name = $(e.target).prev().text().split(" ")[0];
  removeItemFromCart(name);
  displayCart();
});


displayCart();
saveCart();
