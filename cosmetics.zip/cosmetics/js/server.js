const express = require('express');
const { MongoClient } = require('mongodb');

const app = express();
const port = 3000;
const uri = 'mongodb+srv://Naz:Legend007@naz.plxiqc2.mongodb.net/?authSource=Naz&authMechanism=SCRAM-SHA-1';
const databaseName = 'Naz';

const client = new MongoClient(uri);

client.connect()
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB:', error);
  });

// Example route: Get all documents from the "Naz" collection in the "Naz" database
app.get('/oplog.rs', async (req, res) => {
  try {
    const db = client.db(databaseName);
    const collection = db.collection('oplog.rs');
    const documents = await collection.find({}).toArray();
    res.json(documents);
  } catch (error) {
    console.error('Error retrieving documents:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
// webpack.config.js
const path = require('path');

module.exports = {
  entry: './server.js',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'bundle.js',
  },
  target: 'node',
};

