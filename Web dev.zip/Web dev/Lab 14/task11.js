function reverseString(str) {

  return str.split("").reverse().join("");

}
reverseString("hello");