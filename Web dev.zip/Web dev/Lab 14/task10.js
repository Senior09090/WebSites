let typeProduct = window.prompt('Сколько разновидностей товара');

let sum = 0;
for (i=1;sum > 0;) {
    
    let priceProduct = window.prompt('Введите цену ',i,' товара');
    
    let numberProduct = window.prompt ('Введите его кол-во');
    
    sum =sum+(priceProduct*numberProduct)
}
   
let money = window.prompt ('Сколько денег внес покупатель');

if(money <sum) {
console.log('Покупатель должен додать еше ',sum-den , "тенге ");
} 
   else writeln('Сдача равна ',den-sum ,' тенге ');

